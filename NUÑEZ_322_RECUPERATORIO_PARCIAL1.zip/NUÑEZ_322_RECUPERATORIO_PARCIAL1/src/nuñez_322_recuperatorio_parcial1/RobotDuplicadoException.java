package nuñez_322_recuperatorio_parcial1;


public class RobotDuplicadoException extends Exception{

    public RobotDuplicadoException(String message) {
        super(message);
    }
    
}
