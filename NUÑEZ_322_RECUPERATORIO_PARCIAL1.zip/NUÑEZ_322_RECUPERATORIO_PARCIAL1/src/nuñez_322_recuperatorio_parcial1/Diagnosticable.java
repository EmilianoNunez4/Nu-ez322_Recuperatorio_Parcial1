package nuñez_322_recuperatorio_parcial1;


public interface Diagnosticable {
    
    String diagnosticar();
    
}
