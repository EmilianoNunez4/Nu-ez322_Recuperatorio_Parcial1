package nuñez_322_recuperatorio_parcial1;


public class RobotVigilancia extends Robot implements Diagnosticable{
    
    private final int cantidadCamaras;
    private static final int CONSUMO_POR_OPERACION = 4;
    private static final int SUMA_POR_OPERACION = 6;

    public RobotVigilancia(String numeroSerie, String fabricante, PrioridadServicio prioridad, int nivelBateria, int cantidadCamaras) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        validarPositivo(cantidadCamaras, "Cantidad de camaras invalida");
        this.cantidadCamaras = cantidadCamaras;
    }

    @Override
    public int calcularConsumo() {
        return (cantidadCamaras * CONSUMO_POR_OPERACION) + SUMA_POR_OPERACION;
    }

    @Override
    public String diagnosticar() {
        return "Soy el Robot de VIGILANCIA del fabricante " + getFabricante() + " y estoy diagnosticado" + "\n" +
                "Numero serie: "+getNumeroSerie() + " Nivel bateria: " + getNivelBateria();
    }

    @Override
    public String toString() {
        return "RobotVigilancia{" + super.toString() + "cantidadCamaras=" + cantidadCamaras + '}';
    }
    

}
