package nuñez_322_recuperatorio_parcial1;

import java.util.Objects;


public abstract class Robot {
    
    private final String numeroSerie;
    private final String fabricante;
    private final PrioridadServicio prioridad;
    private int nivelBateria;
    private static final int BATERIA_MAXIMA =100;
    private static final int BATERIA_MINIMA =0;

    public Robot(String numeroSerie, String fabricante, PrioridadServicio prioridad, int nivelBateria) {
        Objects.requireNonNull(prioridad);
        this.numeroSerie = numeroSerie;
        this.fabricante = fabricante;
        this.prioridad = prioridad;
        this.nivelBateria = nivelBateria;
               
        validarTexto(fabricante, "Nombre de fabricante invalido");
        validarTexto(numeroSerie, "Numero de Serie invalido");
        validarBateria();
    }

    public abstract int calcularConsumo();
    
    private void validarBateria(){
        if(nivelBateria < 0 || nivelBateria > 100){
            throw new IllegalArgumentException("Bateria invalida");
        }
    }
    
    public void validarPositivo(int parametro, String mensaje){
        if(parametro <= 0){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarTexto(String parametro, String mensaje){
        if(parametro == null || parametro.isBlank() || parametro.isEmpty()){
            throw new IllegalArgumentException(mensaje);
        }
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public String getFabricante() {
        return fabricante;
    }

    public PrioridadServicio getPrioridad() {
        return prioridad;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroSerie, fabricante);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Robot otroRobot)) {
            return false;
        }
        return numeroSerie.equals(otroRobot.numeroSerie) && fabricante.equals(otroRobot.fabricante);
    }
    
    
    public void ejecutarServicio() {
        int consumo = calcularConsumo();
        if(this.nivelBateria < consumo){
            throw new IllegalStateException("Bateria sin capcadidad");
        }
        this.nivelBateria -= consumo;
    }
    
    
    @Override
    public String toString() {
        return "Robot{" + "numeroSerie=" + numeroSerie + ", fabricante=" + fabricante + ", prioridad=" + prioridad + ", nivelBateria=" + nivelBateria + '}';
    }

    
}
