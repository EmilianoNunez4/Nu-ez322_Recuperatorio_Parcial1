package nuñez_322_recuperatorio_parcial1;


public class RobotReparto extends Robot implements Diagnosticable, Serviciable{
    
    private final int capacidadCarga;
    private static final int CONSUMO_POR_OPERACION = 3;
    private static final int SUMA_POR_OPERACION = 4;

    public RobotReparto(String numeroSerie, String fabricante, PrioridadServicio prioridad, int nivelBateria, int capacidadCarga) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        validarPositivo(capacidadCarga, "Capacidad de carga invalida");
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public int calcularConsumo() {
        return (capacidadCarga*CONSUMO_POR_OPERACION) + SUMA_POR_OPERACION;
    }

    @Override
    public String diagnosticar() {
        return "Soy el Robot de REPARTO del fabricante " + getFabricante() + " y estoy diagnosticado" + "\n" +
                "Numero serie: "+getNumeroSerie() + " Nivel bateria: " + getNivelBateria();
    }

    @Override
    public String Servicio() {
        ejecutarServicio();
        return "Servicio ejecutado por el robot de Reparto. fabricante: " + getFabricante() + " numero serie: " + getNumeroSerie();
    }

    @Override
    public String toString() {
        return "RobotReparto{" + super.toString() + "capacidadCarga=" + capacidadCarga + '}';
    }
    
    
}
