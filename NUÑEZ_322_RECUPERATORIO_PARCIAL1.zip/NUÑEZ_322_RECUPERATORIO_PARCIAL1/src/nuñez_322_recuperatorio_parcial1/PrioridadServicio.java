package nuñez_322_recuperatorio_parcial1;


public enum PrioridadServicio {
    
    BAJA,
    MEDIA,
    ALTA
    
}
