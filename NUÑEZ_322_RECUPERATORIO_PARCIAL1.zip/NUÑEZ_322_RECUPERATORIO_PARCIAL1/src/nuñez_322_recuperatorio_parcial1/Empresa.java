package nuñez_322_recuperatorio_parcial1;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Empresa {
    
    private final String nombre;
    private final List<Robot> robots = new ArrayList<>();

    public Empresa(String nombre) {
        if(nombre == null || nombre.isBlank() || nombre.isEmpty()){
            throw new IllegalArgumentException("Nombre invalido");
        }
        this.nombre = nombre;
    }
    
    public void agregarRobot(Robot robot) throws RobotDuplicadoException{
        Objects.requireNonNull(robot);
        if(robots.contains(robot)){
            throw new RobotDuplicadoException("El robot del fabricante " + robot.getFabricante() + " y codigo de serie " + robot.getNumeroSerie() + " ya existe");
        }
        robots.add(robot);
    }
    
    public List<Robot> obtenerRobots(){
        return new ArrayList<Robot>(robots);
    }
    
    public List<Robot> filtrarPorPrioridad(PrioridadServicio prioridad){
        List<Robot> nuevaL = new ArrayList<>();
        for(Robot r : robots){
            if(r.getPrioridad() == prioridad){
                nuevaL.add(r);
            }
        }
        return nuevaL;
    }
    
    public List<Robot> obtenerRobotsConConsumoMaximo(int maximo){
        List<Robot> listaFiltrada = new ArrayList<>();
        for(Robot r : robots){
            if(r.calcularConsumo() <= maximo){
               listaFiltrada.add(r);
            }
        }
        return listaFiltrada;
    }
    
}
