package nuñez_322_recuperatorio_parcial1;


public class RobotLimpieza extends Robot implements Serviciable{
    
    private final int superficieTrabajo;
    private static final int CONSUMO_POR_OPERACION = 10;
    private static final int SUMA_POR_OPERACION = 5;

    public RobotLimpieza(String numeroSerie, String fabricante, PrioridadServicio prioridad, int nivelBateria, int superficieTrabajo) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        validarPositivo(superficieTrabajo, "Superficie invalida");
        this.superficieTrabajo = superficieTrabajo;
    }

    @Override
    public int calcularConsumo() {
        return (superficieTrabajo/CONSUMO_POR_OPERACION) + SUMA_POR_OPERACION;
    }

    @Override
    public String toString() {
        return "RobotLimpieza{" + super.toString() + "superficieTrabajo=" + superficieTrabajo + '}';
    }

    @Override
    public String Servicio() {
        ejecutarServicio();
        return "Servicio ejecutado por el robot de Limpieza. fabricante: " + getFabricante() + " numero serie: " + getNumeroSerie();
    }
    
    
}
