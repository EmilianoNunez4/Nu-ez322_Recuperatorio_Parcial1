package nuñez_322_recuperatorio_parcial1;

import java.util.List;


public class NUÑEZ_322_RECUPERATORIO_PARCIAL1 {

    
    public static void main(String[] args) {
    Empresa flota = new Empresa("TecnoAsistencia");
    
    try {
    flota.agregarRobot(new RobotLimpieza("RL-10", "Nova", PrioridadServicio.ALTA, 60, 80));
    flota.agregarRobot(new RobotVigilancia("RV-20", "Orbis", PrioridadServicio.MEDIA, 75, 3));
    flota.agregarRobot(new RobotReparto("RR-30", "Nova", PrioridadServicio.BAJA, 40, 5));
    flota.agregarRobot(new RobotReparto("RR-40", "Orbis", PrioridadServicio.ALTA, 15, 4));
    flota.agregarRobot(new RobotVigilancia("RL-10", "Nova", PrioridadServicio.BAJA, 90, 2));
    } catch (RobotDuplicadoException ex) {
        System.out.println(ex.getMessage());
    }
    System.out.println("Robots registrados:");
    mostrarRobots(flota.obtenerRobots());
    System.out.println("\nEjecución de servicios:");
    ejecutarServicios(flota.obtenerRobots());
    System.out.println("\nDiagnósticos:");
    generarDiagnosticos(flota.obtenerRobots());
    System.out.println("\nRobots de prioridad ALTA:");
    mostrarRobots(flota.filtrarPorPrioridad(PrioridadServicio.ALTA));
    System.out.println("\nRobots con consumo máximo de 18:");
    mostrarRobots(flota.obtenerRobotsConConsumoMaximo(18));
    System.out.println("\nConsumos actuales:");
    mostrarConsumos(flota.obtenerRobots());
    }
    
    private static void mostrarRobots(List<Robot> robots) {
    // Completar
        for(Robot r : robots){
            System.out.println(r);
        }
    }
    
    private static void ejecutarServicios(List<Robot> robots) {
    // Completar: manejar la falta de batería por robot,
    // sin interrumpir el recorrido.
        for(Robot r : robots){
            if(r instanceof Serviciable serviciable){
                try{
                    System.out.println(serviciable.Servicio());
                } catch( IllegalStateException ex){
                    System.out.println("No se pudo ejecutar, bateria muy baja");
                }
            }
        }
    }
    
    private static void generarDiagnosticos(List<Robot> robots) {
    // Completar
        for(Robot r : robots){
            if(r instanceof Diagnosticable diagnostico){
                System.out.println(diagnostico.diagnosticar());
            }
        }
    }
    
    private static void mostrarConsumos(List<Robot> robots) {
        for(Robot r : robots){
            System.out.println(r.calcularConsumo());
        }
   }
}

